import pytesseract 
from PIL import Image 

def extract_text_from_image (file_path :str )->str :

    try :
        img =Image .open (file_path )

        text =pytesseract .image_to_string (img ,lang ="eng")
        return text .strip ()
    except pytesseract .TesseractNotFoundError :
        raise RuntimeError (
        "Tesseract is not installed or not in PATH. "
        "Install it: sudo apt install tesseract-ocr"
        )
    except Exception as e :
        raise RuntimeError (f"OCR extraction failed: {e }")
