import os 
from backend .services .pdf_service import extract_text_from_pdf 
from backend .services .ocr_service import extract_text_from_image 

PDF_EXTENSIONS ={".pdf"}
IMAGE_EXTENSIONS ={".jpg",".jpeg",".png",".bmp",".tiff",".tif",".webp"}

def extract_text (file_path :str )->str :
    
    ext =os .path .splitext (file_path )[1 ].lower ()

    if ext in PDF_EXTENSIONS :
        return extract_text_from_pdf (file_path )
    elif ext in IMAGE_EXTENSIONS :
        return extract_text_from_image (file_path )
    else :
        raise ValueError (
        f"Unsupported file type: '{ext }'. "
        f"Supported types: PDF, JPG, JPEG, PNG, BMP, TIFF, WEBP."
        )
