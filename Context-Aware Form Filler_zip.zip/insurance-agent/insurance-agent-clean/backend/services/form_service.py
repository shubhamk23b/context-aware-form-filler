import json 
import os 

_SCHEMA_PATH =os .path .join (os .path .dirname (__file__ ),"../data/form_schema.json")
_EXPLANATIONS_PATH =os .path .join (os .path .dirname (__file__ ),"../data/field_explanations.json")

with open (_SCHEMA_PATH )as f :
    FORM_SCHEMA =json .load (f )

with open (_EXPLANATIONS_PATH )as f :
    FIELD_EXPLANATIONS =json .load (f )

ALL_FIELDS =FORM_SCHEMA ["fields"]
REQUIRED_FIELDS =[field ["key"]for field in ALL_FIELDS if field ["required"]]
ALL_FIELD_KEYS =[field ["key"]for field in ALL_FIELDS ]
CATEGORIES =FORM_SCHEMA ["categories"]

def get_missing_fields (form_data :dict )->dict :

    filled_keys =set (k for k ,v in form_data .items ()if v and str (v ).strip ())

    missing_required =[
    key for key in REQUIRED_FIELDS if key not in filled_keys 
    ]
    missing_optional =[
    field ["key"]for field in ALL_FIELDS 
    if not field ["required"]and field ["key"]not in filled_keys 
    ]
    return {
    "missing_required":missing_required ,
    "missing_optional":missing_optional 
    }

def compute_progress (form_data :dict )->dict :

    filled_keys =set (k for k ,v in form_data .items ()if v and str (v ).strip ())
    filled_total =len (filled_keys &set (ALL_FIELD_KEYS ))
    filled_req =len (filled_keys &set (REQUIRED_FIELDS ))
    total =len (ALL_FIELD_KEYS )
    total_required =len (REQUIRED_FIELDS )

    missing =get_missing_fields (form_data )

    return {
    "total_fields":total ,
    "required_fields":total_required ,
    "filled_fields":filled_total ,
    "filled_required":filled_req ,
    "percent_total":round ((filled_total /total )*100 ,1 ),
    "percent_required":round ((filled_req /total_required )*100 ,1 ),
    "missing_required":missing ["missing_required"],
    "missing_optional":missing ["missing_optional"]
    }

def get_form_with_schema (form_data :dict )->list :
    
    result =[]
    for field in ALL_FIELDS :
        key =field ["key"]
        value =form_data .get (key ,"")
        result .append ({
        **field ,
        "value":value ,
        "filled":bool (value and str (value ).strip ()),
        "explanation":FIELD_EXPLANATIONS .get (key ,""),
        "category_label":CATEGORIES .get (field ["category"],field ["category"])
        })
    return result 

def get_next_question (missing_required :list )->dict |None :
  
    if not missing_required :
        return None 
    key =missing_required [0 ]

    label =next ((f ["label"]for f in ALL_FIELDS if f ["key"]==key ),key )
    explanation =FIELD_EXPLANATIONS .get (key ,"This field is required for your application.")
    return {
    "field_key":key ,
    "label":label ,
    "explanation":explanation ,
    "question":f"Could you provide your {label .lower ()}? {explanation }"
    }
