import json 
import os 
from openai import OpenAI 

client =OpenAI (api_key =os .getenv ("OPENAI_API_KEY"))

EXTRACTION_SYSTEM_PROMPT = (
    "You are an insurance document parser. Extract these fields from the document text: "
    "full_name, dob, age, gender, marital_status, phone, email, address, city, pincode, "
    "aadhaar, pan, occupation, employer, annual_income, height, weight, smoking_status, "
    "pre_existing, nominee_name, nominee_relation, nominee_dob, policy_type, coverage_amount, policy_term. "
    "Return ONLY a valid JSON object. Use null for missing fields. "
    "Normalize dates to DD-MM-YYYY. No markdown, no explanation."
)

def extract_fields_from_text (document_text :str )->dict :
   
    try :
        response =client .chat .completions .create (
        model ="gpt-4o-mini",
        messages =[
        {"role":"system","content":EXTRACTION_SYSTEM_PROMPT },
        {"role":"user","content":f"Extract fields from this document:\n\n{document_text [:4000 ]}"}
        ],
        temperature =0 ,
        max_tokens =800 
        )
        raw =response .choices [0 ].message .content .strip ()

        if raw .startswith ("```"):
            raw =raw .split ("```")[1 ]
            if raw .startswith ("json"):
                raw =raw [4 :]
        data =json .loads (raw )

        return {k :v for k ,v in data .items ()if v is not None and v !=""}
    except Exception as e :
        print (f"[LLM] Extraction error: {e }")
        return {}

AGENT_SYSTEM_PROMPT = (
    "You are Kavya, a helpful insurance form assistant. "
    "Ask for missing fields one or two at a time, always briefly explaining why each is needed. "
    "Confirm values provided by the user. Keep responses under 100 words. "
    "If unrelated to the form, politely redirect."
)

def chat_with_agent (
conversation_history :list ,
user_message :str ,
missing_fields :list ,
field_explanations :dict 
)->tuple [str ,dict ]:
    

    if missing_fields :
        missing_context ="Missing required fields: "+", ".join (missing_fields [:5 ])
    else :
        missing_context ="All required fields are filled! Just confirm with the user."

    system_with_context =AGENT_SYSTEM_PROMPT +f"\n\nCurrent status: {missing_context }"

    messages =[{"role":"system","content":system_with_context }]
    messages .extend (conversation_history [-10 :])
    messages .append ({"role":"user","content":user_message })

    try :
        response =client .chat .completions .create (
        model ="gpt-4o-mini",
        messages =messages ,
        temperature =0.7 ,
        max_tokens =300 
        )
        reply =response .choices [0 ].message .content .strip ()
    except Exception as e :
        reply =f"I'm having trouble connecting. Please try again. (Error: {e })"

    extracted =_extract_from_reply (user_message ,missing_fields )

    return reply ,extracted 

def _extract_from_reply (user_message :str ,missing_fields :list )->dict :
    if not missing_fields :
        return {}
    fields_str =", ".join (missing_fields )
    prompt =f"""
The user said: "{user_message }"

Extract values for these specific fields from their message: {fields_str }
Return ONLY a JSON object with the extracted values.
Use null for any field not mentioned.
Do not include any other text.
"""
    try :
        response =client .chat .completions .create (
        model ="gpt-4o-mini",
        messages =[{"role":"user","content":prompt }],
        temperature =0 ,
        max_tokens =200 
        )
        raw =response .choices [0 ].message .content .strip ()
        if raw .startswith ("```"):
            raw =raw .split ("```")[1 ]
            if raw .startswith ("json"):
                raw =raw [4 :]
        data =json .loads (raw )
        return {k :v for k ,v in data .items ()if v is not None and v !=""}
    except Exception :
        return {}
