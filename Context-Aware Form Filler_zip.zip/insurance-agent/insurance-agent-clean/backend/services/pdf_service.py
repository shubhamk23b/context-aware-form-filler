import fitz 

def extract_text_from_pdf (file_path :str )->str :
    text_parts =[]
    try :
        doc =fitz .open (file_path )
        for page_num in range (len (doc )):
            page =doc [page_num ]
            page_text =page .get_text ("text")
            if page_text .strip ():
                text_parts .append (f"--- Page {page_num +1 } ---\n{page_text }")
        doc .close ()
    except Exception as e :
        raise RuntimeError (f"PDF extraction failed: {e }")

    if not text_parts :
        return ""
    return "\n".join (text_parts )
