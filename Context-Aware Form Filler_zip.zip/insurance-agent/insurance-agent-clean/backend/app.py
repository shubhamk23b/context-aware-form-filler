import os 
from fastapi import FastAPI 
from fastapi .middleware .cors import CORSMiddleware 
from fastapi .staticfiles import StaticFiles 
from fastapi .responses import FileResponse 
from dotenv import load_dotenv 

load_dotenv ()

from backend import database as db 
from backend .routes import upload ,chat ,form 

app =FastAPI (
title ="Insurance Form Filling Agent",
description ="Context-aware AI agent that auto-fills insurance forms from documents.",
version ="1.0.0"
)

app .add_middleware (
CORSMiddleware ,
allow_origins =["*"],
allow_methods =["*"],
allow_headers =["*"]
)

@app .on_event ("startup")
def startup ():
    db .init_db ()
    os .makedirs ("uploads",exist_ok =True )
    print (" Database initialized.")
    if not os .getenv ("OPENAI_API_KEY"):
        print ("  WARNING: OPENAI_API_KEY not set. LLM features will not work.")

app .include_router (upload .router ,tags =["Upload"])
app .include_router (chat .router ,tags =["Chat"])
app .include_router (form .router ,tags =["Form"])

frontend_path =os .path .join (os .path .dirname (__file__ ),"..","frontend")
if os .path .exists (frontend_path ):
    app .mount ("/static",StaticFiles (directory =frontend_path ),name ="static")

    @app .get ("/")
    async def serve_frontend ():
        return FileResponse (os .path .join (frontend_path ,"index.html"))

@app .get ("/health")
async def health ():
    return {"status":"ok","message":"Insurance Agent API is running."}
